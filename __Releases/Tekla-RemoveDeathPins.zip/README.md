# Remove Death Points
Does that and not much more.

## Installation (manual)

If you are installing this manually, do the following

1. Extract the archive into a folder. **Do not extract into the game folder.**
2. Move the contents of `plugins` folder into `<GameDirectory>\Bepinex\plugins`.
3. Run the game.

## Thanks to
@MrPurple6411
@Measurity
@LocalHyena
