# AutoRepair
Workbenches will automatically repair all items they can from your inventory.
I havent touched the check for repairing, which means that lower level workbenchs shoudln't repair higher gear.

## Installation (manual)

If you are installing this manually, do the following

1. Extract the archive into a folder. **Do not extract into the game folder.**
2. Move the contents of `plugins` folder into `<GameDirectory>\Bepinex\plugins`.
3. Run the game.

## Thanks to
@MrPurple6411
@Measurity
@LocalHyena
